/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package retail_db;

/**
 *
 * @author ADMIN
 */
public class RETAIL_DB {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        new Authentication().setVisible(true);
    }
    
}
